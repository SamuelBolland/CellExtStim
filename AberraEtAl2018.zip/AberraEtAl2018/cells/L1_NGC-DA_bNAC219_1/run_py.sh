nrnivmodl ./mechanisms

# Use for python 2.6+
python ./run.py "$@"

# Use for python 3.4+
# python3 ./run.py "$@"
